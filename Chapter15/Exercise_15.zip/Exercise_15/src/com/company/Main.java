package com.company;

import javafx.animation.PathTransition;
import javafx.animation.Timeline;
import javafx.application.Application;
import javafx.collections.ObservableList;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.Pane;
import javafx.scene.paint.Color;
import javafx.scene.shape.*;
import javafx.stage.Stage;
import javafx.scene.Scene;
import javafx.event.EventHandler;
import javafx.util.Duration;

public class Main extends Application{
    @Override
    public void start(Stage primaryStage) {
        Pane pane = new Pane();
        Rectangle rect = new Rectangle(25, 50);
        rect.setFill(Color.WHITE);
        rect.setStroke(Color.BLACK);

        Polygon pentagon = new Polygon();
        pentagon.setFill(Color.WHITE);
        pentagon.setStroke(Color.BLACK);
        ObservableList<Double> list = pentagon.getPoints();
        final double WIDTH = 400;
        final double HEIGHT = 400;

        double centerX = WIDTH / 2, centerY = HEIGHT / 2;
        double radius = Math.min(WIDTH, HEIGHT * 0.4);

        for (int sides = 0; sides < 5; sides++) {
            list.add(centerX + radius * Math.cos(2 * sides * Math.PI / 5));
            list.add(centerY - radius * Math.sin(2 * sides * Math.PI / 5));
        }
        pentagon.setRotate(-90);
        pane.getChildren().clear();
        pane.getChildren().add(pentagon);
        pane.getChildren().add(rect);

        PathTransition path = new PathTransition();
        path.setPath(pentagon);
        path.setNode(rect);
        path.setDuration(Duration.millis(4000));
        path.setOrientation(PathTransition.OrientationType.ORTHOGONAL_TO_TANGENT);
        path.setCycleCount(Timeline.INDEFINITE);
        path.setAutoReverse(true);
        path.play();

        pane.setOnMousePressed(e -> path.pause());
        pane.setOnMouseReleased(e -> path.play());

        Scene scene = new Scene(pane, 400, 400);
        primaryStage.setTitle("Pentagon Rectangle");
        primaryStage.setScene(scene);
        primaryStage.show();
    }
    public static void main(String[] args) {
        launch(args);
    }
}
