package com.company;

import javafx.application.Application;
import javafx.stage.Stage;
import javafx.scene.Scene;
import java.awt.GraphicsDevice;
import java.awt.GraphicsEnvironment;

public class Main extends Application {
    @Override
    public void start(Stage stage) {
        GraphicsDevice gd = GraphicsEnvironment.getLocalGraphicsEnvironment().getDefaultScreenDevice();
        int width = gd.getDisplayMode().getWidth();
        int height = gd.getDisplayMode().getHeight();

        BallPane ballPane = new BallPane();
        Scene scene = new Scene(ballPane, width, height);

        stage.setWidth(width);
        stage.setHeight(height);

        ballPane.setOnKeyPressed(e -> {
            switch (e.getCode()) {
                case DOWN:
                    if (ballPane.getY() <= stage.getHeight() - 60) {
                        ballPane.setY(ballPane.getY() + 10);
                        break;
                    }
                    else ballPane.setY(stage.getHeight() - 50); break;
                case UP:
                    if (ballPane.getY() >= 30) {
                        ballPane.setY(ballPane.getY() - 10);
                        break;
                    }
                    else ballPane.setY(20); break;
                case LEFT:
                    if (ballPane.getX() >= 30) {
                        ballPane.setX(ballPane.getX() - 10);
                        break;
                    }
                    else ballPane.setX(20); break;
                case RIGHT:
                    if (ballPane.getX() <= stage.getWidth() -30) {
                        ballPane.setX(ballPane.getX() + 10);
                        break;
                    }
                    else ballPane.setX(stage.getWidth() - 20);break;
                default:
                    ballPane.setY(ballPane.getY());
                    ballPane.setX(ballPane.getX());
            }
        });
        stage.setTitle("Move the Ball");
        stage.setScene(scene);
        stage.show();
        ballPane.requestFocus();
    }
    public static void main(String[] args) {
        launch(args);
    }
}
