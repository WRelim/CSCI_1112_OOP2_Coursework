package com.company;

import javafx.application.Application;
import javafx.application.Platform;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.TextField;
import javafx.scene.layout.FlowPane;
import javafx.scene.media.Media;
import javafx.scene.media.MediaPlayer;
import javafx.stage.Stage;

public class StopwatchMain extends Application {
    @Override
    public void start(Stage primaryStage) throws Exception {
        Media alarm = new Media(getClass().getResource("/com/company/anthem0.mp3").toExternalForm());
        MediaPlayer player = new MediaPlayer(alarm);
        player.setCycleCount(MediaPlayer.INDEFINITE);
        FlowPane pane = new FlowPane();
        pane.setAlignment(Pos.CENTER);

        TextField tfMessage = new TextField();
        tfMessage.setOnAction(event -> {
            displayContents(tfMessage.getText());

            new Thread(() -> {
                try {
                    int countdown = Integer.parseInt(tfMessage.getText());
                    for (; countdown >= 0; countdown--) {
                        final int finalCountdown = countdown;
                        Platform.runLater(() -> tfMessage.setText(String.valueOf(finalCountdown)));
                        System.out.println(tfMessage.getText());
                        Thread.sleep(1000);
                        if (countdown < 1) {
                            player.play();
                        }
                    }
                } catch (RuntimeException e) {
                    System.out.println("Runtime: " + e);
                } catch (Exception e) {
                    System.out.println("Exception: " + e);
                }
            }).start();
        });

        pane.getChildren().add(tfMessage);

        Scene scene = new Scene(pane, 400, 300);

        primaryStage.setScene(scene);
        primaryStage.setTitle("Stopwatch");
        primaryStage.show();
    }

    public void displayContents(String in) {
        System.out.println(in);
    }

    public static void main(String[] args) {
        launch(args);
    }
}