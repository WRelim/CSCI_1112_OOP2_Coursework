package com.company;

import java.io.*;

public class Main {


    public static void main(String[] args) throws IOException {
        File ioFolder = new File("/Users/student/Documents/jetbrains-workspace/InputOutputFundamental/src/ioFolder");
        boolean folderBoolean = ioFolder.mkdirs();
        if (folderBoolean) {
            System.out.println("Folder created: " + ioFolder.getName());
        }
        try {
            File ioFile = new File("/Users/student/Documents/jetbrains-workspace/InputOutputFundamental/src/ioFolder/ioText.txt");
            if (ioFile.createNewFile()) {
                System.out.println("File created: " + ioFile.getName());
            }
        } catch (IOException e) {
            System.out.println("An error occurred.");
            e.printStackTrace();
        }

        String fileText = "";

        try {
            File ioFile = new File("/Users/student/Documents/jetbrains-workspace/InputOutputFundamental/src/ioFolder/ioText.txt");
            FileReader reader = new FileReader(ioFile);
            BufferedReader bufferedReader = new BufferedReader(reader);

            String line;

            while ((line = bufferedReader.readLine()) != null) {
                fileText = fileText + line;
            }
            reader.close();
        }
        catch (IOException e) {
            e.printStackTrace();
        }

        try {
            File ioFile = new File("/Users/student/Documents/jetbrains-workspace/InputOutputFundamental/src/ioFolder/ioText.txt");
            FileWriter writer = new FileWriter(ioFile);
            writer.write(fileText);
            for (int loop = 0; loop < 99; loop++) {
                writer.write((int) (Math.random() * 10) + " ");
            }
            writer.close();
        } catch (IOException e) {
            e.printStackTrace();
        }

        try {
            File ioFile = new File("/Users/student/Documents/jetbrains-workspace/InputOutputFundamental/src/ioFolder/ioText.txt");
            FileReader reader = new FileReader(ioFile);
            BufferedReader bufferedReader = new BufferedReader(reader);

            String line;

            while ((line = bufferedReader.readLine()) != null) {
                System.out.println(line);
            }
            reader.close();
        }
        catch (IOException e) {
            e.printStackTrace();
        }

    }
}