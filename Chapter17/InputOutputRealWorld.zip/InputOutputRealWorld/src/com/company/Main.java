package com.company;

import java.io.*;

public class Main {

    public static void main(String[] args) throws IOException {
        createFile();
        readFile();
    }
    public static void createFile() {
        File ioFolder = new File("/Users/student/Documents/jetbrains-workspace/InputOutputRealWorld/src/ioFolder");
        boolean folderBoolean = ioFolder.mkdirs();
        if (folderBoolean) {
            System.out.println("Folder created: " + ioFolder.getName());
        }
        try {
            File ioFile = new File("/Users/student/Documents/jetbrains-workspace/InputOutputRealWorld/src/ioFolder/Exercise17_03.dat");
            if (ioFile.createNewFile()) {
                System.out.println("File created: " + ioFile.getName());
            }
            DataOutputStream out = new DataOutputStream(new FileOutputStream("/Users/student/Documents/jetbrains-workspace/InputOutputRealWorld/src/ioFolder/Exercise17_03.dat", true));

            for (int loop = 0; loop < 99; loop++) {
                int rand = (int) (Math.random() * 10);
                out.writeInt(rand);
                out.writeUTF(" ");
            }

        } catch (IOException e) {
            System.out.println("An error occurred.");
            e.printStackTrace();
        }
    }

    public static void readFile() {
        File ioFolder = new File("/Users/student/Documents/jetbrains-workspace/InputOutputRealWorld/src/ioFolder");
        boolean folderBoolean = ioFolder.mkdirs();
        if (folderBoolean) {
            System.out.println("Folder created: " + ioFolder.getName());
        }
        try {
            File ioFile = new File("/Users/student/Documents/jetbrains-workspace/InputOutputRealWorld/src/ioFolder/Exercise17_03.dat");
            if (ioFile.createNewFile()) {
                System.out.println("File created: " + ioFile.getName());
            }
            DataInputStream in = new DataInputStream(new FileInputStream("/Users/student/Documents/jetbrains-workspace/InputOutputRealWorld/src/ioFolder/Exercise17_03.dat"));

            int total = 0;
            while(in.available()>0) {
                int k = in.read();
                total = total + k;
            }
            System.out.println(total);
            
        } catch (IOException e) {
            System.out.println("An error occurred.");
            e.printStackTrace();
        }
    }
}