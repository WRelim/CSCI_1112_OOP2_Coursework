package com.company;

import java.io.FileOutputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Scanner;

public class Main {

    public static void main(String[] args) throws Exception {
        int choice = prompt();
        if (choice == 1)
            encrypt();
        else
            decrypt();
    }

    public static int prompt() {
        Scanner input = new Scanner(System.in);
        while (true) {
            System.out.println("1: Encrypt File");
            System.out.println("2: Decrypt File");
            int choice = input.nextInt();
            if (choice == 1)
                return 1;
            else if (choice == 2)
                return 2;
            else {
                System.out.println("Entry is invalid.");
            }
        }
    }

    public static void encrypt() throws Exception {
        Scanner input = new Scanner(System.in);
        System.out.println("Enter a name for the input file:");
        String inputName = input.nextLine();
        System.out.println("Enter a name for the output file:");
        String outputName = input.nextLine();
        if (!inputName.contains(".dat")) {
            inputName = inputName + ".dat";
        }
        if (!outputName.contains(".dat")) {
            outputName = outputName + ".dat";
        }

        Path filePath = Paths.get("/Users/student/Documents/jetbrains-workspace/Programming17_14/src/" + inputName);
        byte[] fileContent = Files.readAllBytes(filePath);
        for (int i = 0; i < fileContent.length; i++) {
            fileContent[i] += 5;
        }
        try (FileOutputStream fos = new FileOutputStream("/Users/student/Documents/jetbrains-workspace/Programming17_14/src/" + outputName)) {
            fos.write(fileContent);
        }
    }

    public static void decrypt() throws Exception {
        Scanner input = new Scanner(System.in);
        System.out.println("Enter a name for the input file:");
        String inputName = input.nextLine();
        System.out.println("Enter a name for the output file:");
        String outputName = input.nextLine();
        if (!inputName.contains(".dat")) {
            inputName = inputName + ".dat";
        }
        if (!outputName.contains(".dat")) {
            outputName = outputName + ".dat";
        }

        Path filePath = Paths.get("/Users/student/Documents/jetbrains-workspace/Programming17_14/src/" + inputName);
        byte[] fileContent = Files.readAllBytes(filePath);
        for (int i = 0; i < fileContent.length; i++) {
            fileContent[i] -= 5;
        }
        try (FileOutputStream fos = new FileOutputStream("/Users/student/Documents/jetbrains-workspace/Programming17_14/src/" + outputName)) {
            fos.write(fileContent);
        }
    }
}