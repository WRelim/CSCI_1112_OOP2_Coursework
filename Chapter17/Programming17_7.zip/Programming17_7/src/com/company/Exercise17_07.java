package com.company;/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author rmazorow
 */

import java.io.*;
import java.util.ArrayList;
import java.util.List;

public class Exercise17_07 {
    public static void main(String[] args) throws FileNotFoundException {
        Loan loan1 = new Loan();
        Loan loan2 = new Loan(1.8, 10, 10000);
//        double total = loan1.getTotalPayment() + loan2.getTotalPayment();
//        System.out.println("Loan 1 " + loan1.getTotalPayment());
//        System.out.println("Loan 2 " + loan2.getTotalPayment());
//        System.out.println(total);
        try (
                ObjectOutputStream output = new ObjectOutputStream(new FileOutputStream("Exercise17_07.dat"));
        ) {
            output.writeObject(loan1);
            output.writeObject(loan2);
        }
        catch (IOException ex) {
            System.out.println("File could not be opened");
        }
        outputData();
    }
    public static void outputData(){
        List<Object> objArray = new ArrayList<>();
        boolean run = true;
        double loanTotal = 0.0;
        try {
            ObjectInputStream input = new ObjectInputStream(new FileInputStream("Exercise17_07.dat"));
            while (run) {
                Object obj;
                try {
                    obj = input.readObject();
                    if (obj != null) {
                        objArray.add(obj);
                    }
                } catch (EOFException e) {
                    break;
                } catch (ClassNotFoundException e) {
                    e.printStackTrace();
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }

        for (int loop = 0; loop < objArray.size(); loop++) {
            loanTotal = loanTotal + findTotalLoan(objArray, loop);
        }
        System.out.println(loanTotal);
    }
    public static double findTotalLoan(List<Object> arr, int t) {
        ArrayList<Loan> loanList = new ArrayList<>();
        for (Object i: arr) {
            loanList.add((Loan) i);
        }
        return loanList.get(t).getTotalPayment();
    }
}
