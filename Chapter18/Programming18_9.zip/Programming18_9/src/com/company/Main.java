package com.company;

import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        System.out.println("Enter a string: ");
        String user = input.nextLine();
        reverseDisplay(user);
    }
    public static void reverseDisplay(String value) {
        if (!value.isEmpty()) {
            char value1 = value.charAt(value.length() - 1);
            String value2 = value.substring(0 , value.length() - 1);
            System.out.print(value1);
            reverseDisplay(value2);
        }
    }
}
