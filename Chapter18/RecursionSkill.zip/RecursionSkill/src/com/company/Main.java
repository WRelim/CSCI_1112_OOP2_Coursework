package com.company;

import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        System.out.println("Enter two integers:");
        String user = input.nextLine();
        String[] userArr = user.split(" ", 2);
        int num1 = Integer.parseInt(userArr[0]);
        int num2 = Integer.parseInt(userArr[1]);
        System.out.println(gCD(num1, num2));
    }
    //Greatest Common Divisor
    public static int gCD(int number, int divisor) {
        if (number % divisor == 0) {
            return divisor;
        }
        else {
            return gCD(divisor,number % divisor);
        }
    }
}
